//
//  DayCollectionViewCell.swift
//  DietRemaindersTask
//
//  Created by naidu yatham on 12/03/18.
//  Copyright © 2018 ESystems. All rights reserved.
//

import UIKit

class DayCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var dayLbl: UILabel!
  
    
    @IBOutlet weak var cellImage: UIImageView!
    
    
}
