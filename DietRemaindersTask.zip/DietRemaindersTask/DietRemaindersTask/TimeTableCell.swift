//
//  TimeTableCell.swift
//  DietRemaindersTask
//
//  Created by naidu yatham on 12/03/18.
//  Copyright © 2018 ESystems. All rights reserved.
//

import UIKit

class TimeTableCell: UITableViewCell {

    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var food: UILabel!
    @IBOutlet weak var reqImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
